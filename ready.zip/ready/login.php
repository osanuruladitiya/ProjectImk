<?php 
    $con = mysqli_connect('localhost', 'root', '','dbready');
 
    // menangkap data yang dikirim dari form login
    $username = $_POST['username'];
    $password = $_POST['password'];   
 
    // menyeleksi data pada tabel admin dengan username dan password yang sesuai
     $data = mysqli_query($con, "SELECT * FROM register WHERE username='$username' and password='$password'");
 
    // // menghitung jumlah data yang ditemukan
     $cek = mysqli_num_rows($data);

     function function_alert($msg) {
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
 
    if($cek > 0){
            echo "<script>
        alert('LOGIN SUKSES');
        window.location.href='menu.html';
        document.write(localStorage.setItem('user', '".$username."'))
        </script>";
    }
    else{
        echo "<script>
        alert('LOGIN GAGAL');
        window.location.href='akun.html';
        </script>";
    }
?>