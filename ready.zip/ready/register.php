<?php
// database connection code
if(isset($_POST['txtName']))
{
// $con = mysqli_connect('localhost', 'database_user', 'database_password','database');
$con = mysqli_connect('localhost', 'root', '','dbready');

// get the post records
$txtName = $_POST['txtName'];
$txtEmail = $_POST['txtEmail'];
$txtPassword = $_POST['txtPassword'];

// database insert SQL code
$sql = "INSERT INTO `register` (`id`, `username`, `email`, `password`) VALUES ('', '$txtName', '$txtEmail', '$txtPassword')";

// insert in database 
$rs = mysqli_query($con, $sql);
if($rs)
{
	echo "<script>
	alert('REGISTER SUKSES');
	window.location.href='menu.html';
	document.write(localStorage.setItem('user', '".$username."'));
	</script>";
}
}
else
{
	echo "<script>
	alert('REGISTER GAGAL');
	window.location.href='menu.html';
	</script>";
	
}
?>